from random import * 


flag = open('flag.txt', 'r').read()
rng = Random()
settings = {"otpSize": 22, "appName":"otp pony"}
users = {}

def gen_otp():
    otp = rng.getrandbits(settings["otpSize"])
    return otp

def create_user(username, role):
    if username in users:
        raise ValueError("User exists")
    otp = gen_otp()
    users[username] = {"password": otp, "role":role}
    return otp

def create_alice():
    create_user("alice", "admin")

def seperator():
    print("-" * 50)

def dashboard(user):
    seperator()
    print("Welcome to " + settings["appName"])
    if users[user]["role"] == "admin":
        print("Flag:",  flag)
    while True:
        print("""1. Edit Settings\n2. Change Password\n3. Quit""")
        choice = input("Choice: ")
        match choice:
            case "1":
                settings["appName"] = input("New App Name: ")
                settings["otpSize"] = int(input("OTP bit number: "))

            case "2": 
                users[user][password] = input("New Password: ")

            case "3":
                break
    seperator()

def main():
    create_alice()
    while True:
        seperator()
        print("""1. Login\n2. Signup \n3. Quit""")
        choice = input("Choice: ")
        match choice:
            case "1":
                user = input("Username: ")
                password = input("Password: ")
                if user in users:
                    if str(users[user]["password"]) == password:
                        dashboard(user);
                    else:
                        print("Incorrect Password")
                else:
                    print("User Does not exist")

            case "2":
                user = input("Username: ")
                otp = create_user(user, "user")
                print(f"Your otp is {otp}")

            case "3":
                break
        seperator()

if __name__ == "__main__":
    main()
